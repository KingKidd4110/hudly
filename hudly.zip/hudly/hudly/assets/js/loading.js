$(document).ready(function() {
    $(".loading-screen").remove();
    $("body").css("overflow", "scroll");
})