<style>
    div:last-child {
  display: none !important;
}
</style>