-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 08, 2022 at 07:33 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hudly`
--
CREATE DATABASE IF NOT EXISTS `hudly` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `hudly`;

-- --------------------------------------------------------

--
-- Table structure for table `advert`
--

CREATE TABLE `advert` (
  `id` int(11) NOT NULL,
  `des` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `cimage` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `advert`
--

INSERT INTO `advert` (`id`, `des`, `cimage`) VALUES
(1, '', '1.jpg'),
(2, '', '2.jpg'),
(3, '', '3.jpg'),
(4, '', '4.jpg'),
(5, '', '5.jpg'),
(6, '', '6.png'),
(7, '', '7.jpeg'),
(8, '', '8.jpeg'),
(9, '', '9.jpeg'),
(10, '', '10.jpeg'),
(11, '', '11.jpg'),
(12, '', '12.webp'),
(13, 'Share your business with the world', 'default.png');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `userid` varchar(200) NOT NULL,
  `product_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `userid`, `product_id`) VALUES
(47, '4', '1'),
(57, '5', '6'),
(71, '6', '5');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`, `status`) VALUES
(1, 'frankemmanuel249@gmail.com', 'subscribed'),
(2, 'peter@gmail.com', 'subscribed'),
(3, 'ebukambanusi55@gmail.com', 'subscribed');

-- --------------------------------------------------------

--
-- Table structure for table `prating`
--

CREATE TABLE `prating` (
  `id` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `rate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prating`
--

INSERT INTO `prating` (`id`, `userid`, `pid`, `rate`) VALUES
(1, '3', '6', '3'),
(3, '3', '5', '4'),
(4, '3', '2', '3'),
(5, '3', '1', '5'),
(6, '5', '6', '3'),
(7, '3', '3', '5'),
(8, '6', '5', '4');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `store` varchar(100) NOT NULL,
  `store_link` varchar(200) NOT NULL,
  `product_image` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_price` int(200) NOT NULL,
  `product_description` text NOT NULL,
  `product_category` varchar(200) NOT NULL,
  `product_quantity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `store`, `store_link`, `product_image`, `product_name`, `product_price`, `product_description`, `product_category`, `product_quantity`) VALUES
(1, 'Jenny Store', 'jenny-store', '3.jpeg', 'Iphone 6s', 400, 'Iphone 6s', 'Phones and Tablets', ''),
(2, 'Jenny Store', 'jenny-store', '2.jpeg', 'Samsung Galaxy S12', 5000, 'London Used Iphone', 'Phones and Tablets', ''),
(3, 'Frank Enterprise', 'frank-enterprise', '1.jpeg', 'Azus Laptop', 2000, 'Brand new Asus Laptop For Sale at a negotiable price', 'Phones and Tablets', ''),
(4, 'Jenny Store', 'jenny-store', '4.jpeg', 'Indomie Instant Noodles', 70, 'Best price', 'Supermarket', ''),
(5, 'Frank Enterprise', 'frank-enterprise', 'f.jpg', 'SkyRun Fridge', 2000, 'Best Fridge', 'Electronics', '2'),
(6, 'Frank Enterprise', 'frank-enterprise', 'g.jpg', 'Fuel Generator', 600, 'This generator is one of the best generators in the world due to its durability and 2 years Warranty', 'Electronics', '1');

-- --------------------------------------------------------

--
-- Table structure for table `saved`
--

CREATE TABLE `saved` (
  `id` int(11) NOT NULL,
  `userid` varchar(200) NOT NULL,
  `product_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `saved`
--

INSERT INTO `saved` (`id`, `userid`, `product_id`) VALUES
(30, '5', '5'),
(32, '3', '5'),
(34, '3', '4'),
(35, '3', '6'),
(36, '3', '1'),
(37, '6', '3');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `id` int(11) NOT NULL,
  `sname` varchar(200) NOT NULL,
  `sphone` varchar(200) NOT NULL,
  `semail` varchar(200) NOT NULL,
  `slink` varchar(200) NOT NULL,
  `simage` varchar(200) DEFAULT NULL,
  `sdesc` varchar(200) DEFAULT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `sname`, `sphone`, `semail`, `slink`, `simage`, `sdesc`, `password`) VALUES
(1, 'Jenny Store', '09071195591', 'jenny@gmail.com', 'jenny-store', '', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsum necessitatibus voluptas ducimus adipisci. Voluptas debitis exercitationem quod vitae, numquam illum et, aperiam amet ad id impedit quam ', '1234'),
(3, 'Frank Enterprise', '09026825301', 'frank@gmail.com', 'frank-enterprise', 'a.jpg', 'This is The No 1 Best Electronic Store that provides quality service', '1c592e3481c4df3b64a4dd38fae38280'),
(5, 'max industry', '08137208039', 'mbanusifrancis9@gmail.com', 'max-industry', NULL, NULL, '1c592e3481c4df3b64a4dd38fae38280');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`) VALUES
(3, 'Ebuka', 'Mbanusi', 'mbanusifrancis9@gmail.com', '1c592e3481c4df3b64a4dd38fae38280'),
(4, 'test2', 'tes2', 'test2@gmail.com', '1c592e3481c4df3b64a4dd38fae38280'),
(5, 'Ebuka', 'Mbanusi', 'frankemmanuel249@gmail.com', '1c592e3481c4df3b64a4dd38fae38280'),
(6, 'elliot', 'test', 'test@gmail.com', '2f6c2404198add983753e94fc24e752f'),
(7, 'Test', 'Test', 'test1@gmail.com', '2f6c2404198add983753e94fc24e752f');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advert`
--
ALTER TABLE `advert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prating`
--
ALTER TABLE `prating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saved`
--
ALTER TABLE `saved`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advert`
--
ALTER TABLE `advert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `prating`
--
ALTER TABLE `prating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `saved`
--
ALTER TABLE `saved`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
